import React, { Component } from 'react'
import'./Header.css'


export default class Header extends Component
{
    render(){

        return(
            <div className="main_header">
                <div className="heading"> shopping cart</div>
            </div>
        )
    }
}